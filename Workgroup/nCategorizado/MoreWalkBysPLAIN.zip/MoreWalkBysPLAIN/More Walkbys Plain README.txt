This mod will make the game generate a walk-by every hour between 7 a.m. and 10 p.m. if there are enough sims in your neighborhood to do so.  (If there aren't enough sims, make some more! :-D  It's good to have at least a few sims who don't have jobs in your neighborhood, so they'll be available to walk by at any hour.)

If your sims live in a house with only one sidewalk, the sim should walk right by your house, so it's easy for your sim to see and greet the walk-by.  If your sims live in a corner lot -- one with sidewalks on TWO sides of your lot -- you may occasionally have to look closely to catch the walkbys, because sometimes they come in one side and go out the other side, spending very little time actually visible.  But if you know the time when sims generally walk by, you should be able to catch them.  In my game, sims usually come at around 20 minutes past the hour, so 7:20, 8:20, 9:20, and so on.

Put VisitGenerator.iff into the GameData\Objects folder of your Sims 1 game.  This file is overriding a file that's inside your Objects.far file, so it has to go into the folder where that far file is.  Make sure you take it out of the folder it came in and put it directly into the Objects folder.

There are THREE versions of this file:  
1.  Version One simply generates more walkbys.  
2.  Version Two generates more walkbys AND is one of the two files you need to eliminate relationship decay.
3.  Version Three eliminates relationship decay withOUT generating more walkbys.

The version you have here is Version One; it generates more walkbys but does not alter relationship decay.

If you decide you want only the usual four walkbys per day again, then simply delete the file I've given you, and the game will go back to using the version that's contained inside the Objects.far file.  

I've used this in my game with no trouble, but if it gives you problems, just delete it.


I hope you enjoy this!

Best wishes,

Corylea

I don't get mail at corylea.com; if you need to contact me, you can send me a PM at ModTheSims or at Reddit; I am Corylea in both places.  If you enjoy the mod, I hope you'll leave a comment to say so; I love hearing from people who use my mods!

