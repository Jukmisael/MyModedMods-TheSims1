Corylea's Farmer Seeds README

This will allow your sims to buy multiple packets of vegetable seeds at one time.  You can buy 5 packets of seeds for the vegetables where the plant doesn't survive harvest -- the carrots and lettuce -- and 3 packets of seeds for the vegetables where the plant DOES survive harvest, the tomatoes and green beans.  Since each packet has 5 seeds, that means you can buy 25 seeds at once for carrots and lettuce and 15 seeds at once for tomatoes and green beans.  Of course you still have the option to buy seeds one packet at a time; this mod does not remove that option.

Although this seems as if it would override another file and need to be put in a special place, it doesn't, and it doesn't. :-)  Put it where you normally put downloads, and it should be fine.

I've used this in my game with no trouble, but if it gives you problems, just delete it.

I've used a magic cookie to prevent conflicts, so this shouldn't conflict with the objects made by other modders.

I hope you enjoy this!

Best wishes,

Corylea

I don't get mail at corylea.com; if you need to contact me, you can send me a PM at ModTheSims or at Reddit; I am Corylea in both places.  If you enjoy the mod, I hope you'll leave a comment to say so; I love hearing from people who use my mods!

